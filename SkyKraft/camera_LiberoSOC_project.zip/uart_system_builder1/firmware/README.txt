Export Firmware README

Microsemi Corporation - Microsemi Libero Software Release v2021.2 (Version 2021.2.0.11)

Date    :    Wed Dec  1 16:26:54 2021
Project :    C:\Users\joice\Documents\uart_system_builder1
