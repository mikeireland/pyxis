#ifndef sbMSS_HW_PLATFORM_H_
#define sbMSS_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Microsemi SmartDesign  Wed Dec  1 16:26:54 2021
*
*Memory map specification for peripherals in sbMSS
*/

/*-----------------------------------------------------------------------------
* CM3 subsystem memory map
* Initiator(s) for this subsystem: CM3 
*---------------------------------------------------------------------------*/
#define SBMSS_SB_0/COREUARTAPB_0_0      0x5000_0000U
#define APB_SAMPLER_WRAPPER_0           0x5000_1000U


#endif /* sbMSS_HW_PLATFORM_H_*/
