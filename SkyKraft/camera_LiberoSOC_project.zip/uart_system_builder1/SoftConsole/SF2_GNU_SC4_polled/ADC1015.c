/*
 * ADC1015.c
 *
 *  Created on: 9 Jun. 2021
 *      Author: Patrick
 */

#include "ADC1015.h"

void start_I2C(void) {
	MSS_I2C_init(I2C_MASTER, MASTER_SER_ADDR, MSS_I2C_PCLK_DIV_960);	// 140MHz/960 = 145kHz (in range of 100-400kHz)
}



float readADC(uint8_t channel, uint8_t capNum) {

	// choose which I2C address is appropriate to communicate with
	uint8_t addr = 0;
	switch(channel){
	case 1:
		addr = ADC_ADDR_GND;
		break;
	case 2:
		addr = ADC_ADDR_GND;
		break;
	case 3:
		addr = ADC_ADDR_VCC;
		break;
	case 4:
		addr = ADC_ADDR_VCC;
		break;
	}

	uint16_t config =
			ADS1X15_REG_CONFIG_CQUE_NONE |    // Disable the comparator (default val)
			ADS1X15_REG_CONFIG_CLAT_NONLAT |  // Non-latching (default val)
			ADS1X15_REG_CONFIG_CPOL_ACTVLOW | // Alert/Rdy active low   (default val)
			ADS1X15_REG_CONFIG_CMODE_TRAD |   // Traditional comparator (default val)
			ADS1X15_REG_CONFIG_MODE_SINGLE;   // Single-shot mode (default)

	// Set PGA/voltage range
	config |= ADS1X15_REG_CONFIG_PGA_4_096V;

	// Set data rate
	config |= RATE_ADS1015_3300SPS;

	//set the MUX setting
	if ((channel == 1 || channel == 3) && capNum == 1) {
		config |= ADS1X15_REG_CONFIG_MUX_SINGLE_0;
	}
	else if ((channel == 1 || channel == 3) && capNum == 2) {
		config |= ADS1X15_REG_CONFIG_MUX_SINGLE_1;
	}
	else if ((channel == 2 || channel == 4) && capNum == 1) {
		config |= ADS1X15_REG_CONFIG_MUX_SINGLE_2;
	}
	else if ((channel == 2 || channel == 4) && capNum == 2) {
		config |= ADS1X15_REG_CONFIG_MUX_SINGLE_3;
	}

	// Set 'start single-conversion' bit
	config |= ADS1X15_REG_CONFIG_OS_SINGLE;

	writeRegister(addr, ADS1X15_REG_POINTER_CONFIG, config);

	// Wait for the conversion to complete
	while (!conversionComplete(addr));

	// Read the conversion results
	raw_value = getLastConversionResults(addr);

	// Scale to volts
	float volt_gain = 0.002;
//	switch (gain) {
//	case GAIN_ONE:
//		volt_gain = 0.002;
//		break;
//	case GAIN_TWO:
//		volt_gain = 0.001;
//		break;
//	case GAIN_FOUR:
//		volt_gain = 0.0005;
//		break;
//	case GAIN_EIGHT:
//		volt_gain = 0.00025;
//		break;
//	case GAIN_SIXTEEN:
//		volt_gain = 0.000125;
//		break;
//	default:
//		volt_gain = 0.0f;
//	}

	return ((float) raw_value) * volt_gain;
}

void writeRegister(uint8_t serial_addr, uint8_t reg, uint16_t value) {
	mss_i2c_status_t status;
	buffer[0] = reg;
	buffer[1] = value >> 8;
	buffer[2] = value & 0xFF;
	MSS_I2C_write(I2C_MASTER, serial_addr, buffer, 3, MSS_I2C_RELEASE_BUS);
	status = MSS_I2C_wait_complete(I2C_MASTER, I2C_TIMEOUT);
	assert(status == MSS_I2C_SUCCESS);
}

uint16_t readRegister(uint8_t serial_addr, uint8_t reg) {
	mss_i2c_status_t status;
	buffer[0] = reg;
	MSS_I2C_write_read(I2C_MASTER,
			serial_addr,
			buffer,
			1,	// bytes to write
			read_buffer,	//second and third indices of buffer
			2,	//bytes to read
			MSS_I2C_RELEASE_BUS);
	status = MSS_I2C_wait_complete(I2C_MASTER, I2C_TIMEOUT);
	assert(status == MSS_I2C_SUCCESS);
	return ((read_buffer[0] << 8) | read_buffer[1]);
}

int16_t getLastConversionResults(uint8_t serial_addr) {
	// Read the conversion results
	uint16_t res = readRegister(serial_addr, ADS1X15_REG_POINTER_CONVERT) >> BIT_SHIFT;
	// We have shifted 12-bit results right 4 bits,
	// so making sure we keep the sign bit intact
	if (res > 0x07FF) {
		// negative number - extend the sign to 16th bit
		res |= 0xF000;
		return (int16_t)res;
	}
	else return (int16_t)res;
}

uint8_t conversionComplete(uint8_t addr) {
	return (readRegister(addr, ADS1X15_REG_POINTER_CONFIG) & 0x8000) != 0;
}

/*------------------------------------------------------------------------------
 * Service the I2C timeout functionality (SysTick_Handler is called every 10mS).
 */
void SysTick_Handler(void)
{
	MSS_I2C_system_tick(I2C_MASTER, 10);
}

