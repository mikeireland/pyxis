/*******************************************************************************
 * (c) Copyright 2015 Microsemi SoC Products Group.  All rights reserved.
 *
 * CoreUARTapb polled transmit and  receive example.
 *
 * Please refer to the file README.txt for further details about this example.
 * 
 * SVN $Revision: 8013 $
 * SVN $Date: 2015-10-13 13:15:00 +0530 (Tue, 13 Oct 2015) $
 */
#include "hal.h"
#include "platform.h"
#include "core_uart_apb.h"
#include "m2sxxx.h"
#include "hal_assert.h"

#include <stdio.h>
#include <string.h>

/* --- PRINTF_BYTE_TO_BINARY macro's --- */
#define PRINTF_BINARY_PATTERN_INT8 "%c%c%c%c%c%c%c%c"
#define PRINTF_BYTE_TO_BINARY_INT8(i)    \
    (((i) & 0x80ll) ? '1' : '0'), \
    (((i) & 0x40ll) ? '1' : '0'), \
    (((i) & 0x20ll) ? '1' : '0'), \
    (((i) & 0x10ll) ? '1' : '0'), \
    (((i) & 0x08ll) ? '1' : '0'), \
    (((i) & 0x04ll) ? '1' : '0'), \
    (((i) & 0x02ll) ? '1' : '0'), \
    (((i) & 0x01ll) ? '1' : '0')

#define REVERSE_PRINTF_BYTE_TO_BINARY_INT8(i)    \
    (((i) & 0x01ll) ? '1' : '0'), \
    (((i) & 0x02ll) ? '1' : '0'), \
    (((i) & 0x04ll) ? '1' : '0'), \
    (((i) & 0x08ll) ? '1' : '0'), \
    (((i) & 0x10ll) ? '1' : '0'), \
    (((i) & 0x20ll) ? '1' : '0'), \
    (((i) & 0x40ll) ? '1' : '0'), \
    (((i) & 0x80ll) ? '1' : '0')

#define PRINTF_BINARY_PATTERN_INT16 \
    PRINTF_BINARY_PATTERN_INT8              PRINTF_BINARY_PATTERN_INT8
#define REVERSE_PRINTF_BYTE_TO_BINARY_INT16(i) \
    REVERSE_PRINTF_BYTE_TO_BINARY_INT8(i), REVERSE_PRINTF_BYTE_TO_BINARY_INT8((i) >> 8)
#define PRINTF_BYTE_TO_BINARY_INT16(i) \
    PRINTF_BYTE_TO_BINARY_INT8((i) >> 8),   PRINTF_BYTE_TO_BINARY_INT8(i)
#define PRINTF_BINARY_PATTERN_INT32 \
    PRINTF_BINARY_PATTERN_INT16             PRINTF_BINARY_PATTERN_INT16
#define REVERSE_PRINTF_BYTE_TO_BINARY_INT32(i) \
    REVERSE_PRINTF_BYTE_TO_BINARY_INT16(i), REVERSE_PRINTF_BYTE_TO_BINARY_INT16((i) >> 16)
#define PRINTF_BYTE_TO_BINARY_INT32(i) \
    PRINTF_BYTE_TO_BINARY_INT16((i) >> 16), PRINTF_BYTE_TO_BINARY_INT16(i)
#define PRINTF_BINARY_PATTERN_INT64    \
    PRINTF_BINARY_PATTERN_INT32             PRINTF_BINARY_PATTERN_INT32
#define PRINTF_BYTE_TO_BINARY_INT64(i) \
    PRINTF_BYTE_TO_BINARY_INT32((i) >> 32), PRINTF_BYTE_TO_BINARY_INT32(i)

#define REVERSE_PRINTF_BYTE_TO_BINARY_10BITS(i)    \
    (((i) & 0x01ll) ? '1' : '0'), \
    (((i) & 0x02ll) ? '1' : '0'), \
    (((i) & 0x04ll) ? '1' : '0'), \
    (((i) & 0x08ll) ? '1' : '0'), \
    (((i) & 0x10ll) ? '1' : '0'), \
    (((i) & 0x20ll) ? '1' : '0'), \
    (((i) & 0x40ll) ? '1' : '0'), \
    (((i) & 0x80ll) ? '1' : '0'), \
	(((i) & 0x100ll) ? '1' : '0'), \
	(((i) & 0x200ll) ? '1' : '0')

#define REVERSE_PRINTF_BYTE_TO_BINARY_12BITS(i)    \
    (((i) & 0x01ll) ? '1' : '0'), \
    (((i) & 0x02ll) ? '1' : '0'), \
    (((i) & 0x04ll) ? '1' : '0'), \
    (((i) & 0x08ll) ? '1' : '0'), \
    (((i) & 0x10ll) ? '1' : '0'), \
    (((i) & 0x20ll) ? '1' : '0'), \
    (((i) & 0x40ll) ? '1' : '0'), \
    (((i) & 0x80ll) ? '1' : '0'), \
	(((i) & 0x100ll) ? '1' : '0'), \
	(((i) & 0x200ll) ? '1' : '0'), \
	(((i) & 0x400ll) ? '1' : '0'), \
	(((i) & 0x800ll) ? '1' : '0')

#define PRINTF_BINARY_PATTERN_10BITS "%c%c%c%c%c%c%c%c%c%c"
#define PRINTF_BINARY_PATTERN_12BITS "%c%c%c%c%c%c%c%c%c%c%c%c"
/* --- end macros --- */

/******************************************************************************
 * Baud value to achieve a 57600 baud rate with a 71MHz system clock.
 * This value is calculated using the following equation:
 *      BAUD_VALUE = (CLOCK / (16 * BAUD_RATE)) - 1
 *****************************************************************************/
#define BAUD_VALUE_57600    76
//#define BAUD_VALUE_9600		650		// 100MHz
#define BAUD_VALUE_9600		910   // 140MHz


/******************************************************************************
 * Maximum receiver buffer size.
 *****************************************************************************/
#define MAX_RX_DATA_SIZE    256

/******************************************************************************
 * CoreUARTapb instance data.
 *****************************************************************************/
UART_instance_t g_uart;

/******************************************************************************
 * function prototypes
 *****************************************************************************/

 void printbuffer10by3(uint32_t* bArray, int bLength);
 void printbuffer12by2(uint32_t* bArray, int bLength);


/******************************************************************************
 * main function.
 *****************************************************************************/
int main( void )
{
    uint8_t rx_data[MAX_RX_DATA_SIZE];
    size_t rx_size;

    /**************************************************************************
     * Initialize CoreUARTapb with its base address, baud value, and line
     * configuration.
     *************************************************************************/
    UART_init( &g_uart, COREUARTAPB0_BASE_ADDR,
    		BAUD_VALUE_9600, (DATA_8_BITS | NO_PARITY) );


#define APB_SAMPLER_BASE_ADDR 				0x50001000UL
#define BUFFERCONTENTA_REG_OFFSET			0x00u

#define BUFFERNUMBERA_REG_OFFSET			0x04u
#define TESTA_REG_OFFSET					0x08u
#define BUFFERCONTROLA_REG_OFFSET				0x0Cu
#define RECORDINGBITSA_REG_OFFSET			0x1Cu

#define COUNTERLOADA_REG_OFFSET				0x00u
#define COUNTERVALUEA_REG_OFFSET			0x04u
#define COUNTERCONTROLA_REG_OFFSET			0x08u


    uint8_t print_string[90];

    uint64_t buffer_indicies_captured = 0;
    uint32_t buffer_data = 0x0000;
    uint8_t buffer_index_array[64];
    uint32_t prev_buffer_index = 0;

    uint32_t test = 0;

    test = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, TESTA);
    //HAL_ASSERT(test == 0xA888001)
    HAL_set_32bit_reg( APB_SAMPLER_BASE_ADDR, TESTA, (uint_fast32_t)0xFFFF0000);

    test = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, TESTA);
    HAL_ASSERT(test == 0xFFFF0000)
    //test = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERNUMBERA);
    //HAL_set_8bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERNUMBERA, (uint_fast8_t)0x0001);
    //test = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERNUMBERA);
    //HAL_set_8bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERNUMBERA, (uint_fast8_t)0x0001);
    //test = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERNUMBERA);
//    test = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERCONTENTA);
//
//
//
//    test = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERNUMBERA);
//    test = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERCONTENTA);
//    HAL_set_8bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERNUMBERA, (uint_fast8_t)0x0002);
//    test = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERNUMBERA);
//    test = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERCONTENTA);
//    HAL_ASSERT(test == 0x99999999)
//    test = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERCONTENTA);
//    HAL_ASSERT(test == 0x99999999)
//    test = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, TESTA);
//    HAL_ASSERT(test == 0x99999999)

    //HAL_set_32bit_reg( APB_SAMPLER_BASE_ADDR, TESTA, (uint_fast32_t)0xFFFF0000);
    //test = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, TESTA);


    //buffer_data = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERCONTENTA);
    //buffer_index =  HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERNUMBERA);


    /**************************************************************************
     * Infinite Loop.
     *************************************************************************/
    uint32_t BitsReady = 0;
    uint32_t BitsReadyB = 0;
    uint16_t FreqInit = 0;
    uint16_t FreqB = 0;
    uint16_t FreqC = 0;

    int numberBuffers = 512;
    uint32_t buffer_array[numberBuffers];
    while(1)
    {
    	memset(buffer_array,0,numberBuffers*sizeof(uint32_t));

    	//reset
        HAL_set_32bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERCONTROLA, (uint_fast32_t)0x00000000);
        HAL_set_32bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERCONTROLA, (uint_fast32_t)0x00000001);

        HAL_ASSERT((HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, RECORDINGBITSA) & 0x01) == 0)
        BitsReady = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, RECORDINGBITSA) & 0x01;
        FreqInit = (HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, RECORDINGBITSA) & 0x3FE) >> 1;
        // Bits Ready should be zero
        HAL_ASSERT((HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, RECORDINGBITSA) & 0x01) == 0)

        // wait until bits are ready
		while ( ( HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, RECORDINGBITSA) & 0x01) == 0);
		FreqB = (HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, RECORDINGBITSA) & 0x3FE) >> 1;

        for (int i = 0; i < numberBuffers; i++) {
        	//grab numberBuffers of buffers as fast as possible
        	buffer_array[i] = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, BUFFERCONTENTA);
        }

        FreqC = (HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, RECORDINGBITSA) & 0x3FE) >> 1;
        BitsReadyB = HAL_get_32bit_reg( APB_SAMPLER_BASE_ADDR, RECORDINGBITSA) & 0x01;

        //uint8_t g_message[] =
         //   	    "\n\r\n\r full buffers received. \n\rPrinting out... \n\r\n\r";
          //  	    UART_send( &g_uart, g_message, sizeof(g_message) );



        printbuffer12by2(buffer_array,numberBuffers);

    }
}

void printbuffer10by3(uint32_t* bArray, int bLength) {
	uint16_t data_array[bLength*3];
	uint8_t print_string[90];

	memset(data_array,0,bLength*3*sizeof(uint16_t));

	int prevFlag = !(bArray[0] & 0x80000000);
	int j = 0;
	for (int i = 0; i < bLength; i++) {
		int test = ((uint32_t)(bArray[i] & 0x80000000)>>31);
		if ( ((uint32_t)(bArray[i] & 0x80000000)>>31) != prevFlag) {
			data_array[j*3] = (bArray[i] & 0x3FF);
			data_array[j*3+1] = (bArray[i] & 0xFFC00) >> 10;
			data_array[j*3+2] = (bArray[i] & 0x3FF00000) >> 20;
			j++;

		}
		prevFlag = ((uint32_t)(bArray[i] & 0x80000000)>>31);
		sprintf(print_string, "Buffer number: %2d. j: %2d. Data: %8X b: " PRINTF_BINARY_PATTERN_INT32 "\n\r",i,j,bArray[i],PRINTF_BYTE_TO_BINARY_INT32(bArray[i]));
		UART_send( &g_uart, print_string, 79 );

	}

	for (int k = 0; k < j*3; k++) {
		sprintf(print_string, "pixel number: %2d. Data: %4X b: " PRINTF_BINARY_PATTERN_10BITS "\n\r",k,data_array[k],REVERSE_PRINTF_BYTE_TO_BINARY_10BITS(data_array[k]));

		UART_send( &g_uart, print_string, 45 );
	}

}

void printbuffer12by2(uint32_t* bArray, int bLength) {
	uint16_t data_array[bLength*2];
	uint8_t print_string[90];

	memset(data_array,0,bLength*2*sizeof(uint16_t));

	int prevFlag = !(bArray[0] & 0x80000000);
	int j = 0;
	for (int i = 0; i < bLength; i++) {
		int test = ((uint32_t)(bArray[i] & 0x80000000)>>31);
		if ( ((uint32_t)(bArray[i] & 0x80000000)>>31) != prevFlag) {
			data_array[j*2] = (bArray[i] & 0xFFF);
			data_array[j*2+1] = (bArray[i] & 0xFFF000) >> 12;
			j++;

		}
		prevFlag = ((uint32_t)(bArray[i] & 0x80000000)>>31);
		sprintf(print_string, "Buffer number: %2d. j: %2d. Data: %8X b: " PRINTF_BINARY_PATTERN_INT32 "\n\r",i,j,bArray[i],PRINTF_BYTE_TO_BINARY_INT32(bArray[i]));
		UART_send( &g_uart, print_string, 79 );

	}

	uint8_t g_message[] =
	            	    "\n\r\n\r printed with bit received first to the left of each line, 12 bits per line, not necessarily starting at a particular bit \n\r\n\r";
	            	    UART_send( &g_uart, g_message, sizeof(g_message) );

	for (int k = 0; k < j*2; k++) {
		sprintf(print_string, "pixel number: %2d. Data: %4X b: " PRINTF_BINARY_PATTERN_12BITS "\n\r",k,data_array[k],REVERSE_PRINTF_BYTE_TO_BINARY_12BITS(data_array[k]));

		UART_send( &g_uart, print_string, 47 );
	}

}
